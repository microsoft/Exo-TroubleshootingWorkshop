﻿##########################################################################################################
# This sample script is not supported under any Microsoft standard support program or service.
# The sample scripts are provided AS IS without warranty of any kind. Microsoft further disclaims
# all implied warranties including, without limitation, any implied warranties of merchantability
# or of fitness for a particular purpose. The entire risk arising out of the use or performance of the
# sample scripts and documentation remains with you. In no event shall Microsoft, its authors, or anyone
# else involved in the creation, production, or delivery of the scripts be liable for any damages 
# whatsoever (including, without limitation, damages for loss of business profits, business interruption, 
# loss of business information, or other pecuniary loss) arising out of the use of or inability to use the
# sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#
# Script Name:               Challenge 5 and 6.ps1
#
##########################################################################################################

$E15Session = get-pssession | ?{$_.ComputerName -like "E2K19*"} | ?{$_.ConfigurationName -eq "Microsoft.Exchange"}
$MsolCredential = Get-Credential -Message "Please provide Office 365 Tenant Global Admin credential, example: admin@LODSNNNNNN.onmicrosoft.com"

        #EXO Connection
        try
            {
                $EXOSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $MsolCredential -Authentication Basic -AllowRedirection -WarningAction SilentlyContinue
                $import = Import-PSSession $EXOSession -WarningAction SilentlyContinue -AllowClobber -disablenamechecking
            }
        catch
            {
                $Message = 'Error: Failed to connect to Exchange Online!'
                Write-Host $Message -ForegroundColor Red
            }

#endconnectexo
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#lab 7 break
$fwbreak = Netsh advfirewall firewall add rule name="Inbound_Block_443" dir=in action=block protocol=tcp localport=443

$MRSBreak = Stop-service MSExchangemailboxreplication



#lab 8 break

try
{$eli = get-mailbox eli -erroraction stop

$newrule = New-InboxRule -Mailbox $eli.alias -Name "Messages I don't care about" -DeleteMessage $true -Confirm:$false -From User31
#inbox rule to send messages to eli's junk mailbox
Import-pssession $E15Session -AllowClobber -DisableNameChecking



#generate a message to eli that should fail his new junk email rule
$Sender = get-mailbox User31
$From = $Sender.PrimarySmtpAddress.Address
$Recipient = get-remotemailbox eli
$to = $Recipient.PrimarySmtpAddress.Address
$subject = "Happy Hour Info"

$secondstosleep = 10
#how long of a delay after creating transport rule until we attempt to generate a message

Start-Sleep -Seconds $secondstosleep

$SendMsg = Send-MailMessage -To $to -From $from -Subject $subject -body "Good morning team, Let's all get together this evening to celebrate our recent achievement." -SmtpServer E2K19
}#endtry
catch
{Write-Host "Unable to find mailbox for Eli Bowen. Please make sure Lab 1 has been completed"}
Remove-pssession $EXOSession


